package com.rs.game.goverment;

import java.io.Serializable;

/**
 * Created by JTlr Frost {@skype;frostbitersps} on 7/17/2016.
 */
public class Goverment implements Serializable {

    private static final long serialVersionUID = -5917629775691035442L;

    /*
     * Data & Information
     */

    /**
     * Executive and Legislative branches are elected by the people, members of the Judicial Branch.
     */



}
