package com.rs.game.goverment.impl;

/**
 * Created by JTlr Frost {@skype;frostbitersps} on 7/17/2016.
 */

/**
 *
 */

public class Judicial {
}
