package com.rs.game.npc.others;

public class Hati {

}
