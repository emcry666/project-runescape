package com.rs.game.minigames;

public class FarmingPatches {

}
