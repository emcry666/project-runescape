package com.rs.game;

public class EntitySpawning {
	
	public static void init() {
		World.spawnObject(new WorldObject(93069, 10, 0, 2207,
				3368, 2), true);
	}

}
