package com.rs.game.goverment.impl;

/**
 * Created by JTlr Frost {@skype;frostbitersps} on 7/17/2016.
 */
public class Executive {

    /**
     * Can make law, known as 'Common law', by settling precedent for other judges to follow.
     * Interprets law and applies it to the facts of each case. (Reasoning)
     */
}
