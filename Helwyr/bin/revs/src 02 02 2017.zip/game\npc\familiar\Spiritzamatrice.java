package com.rs.game.npc.familiar;

public class Spiritzamatrice {

}
